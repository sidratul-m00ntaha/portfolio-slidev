---
theme: seriph
title: "Portfolio - Sidratul Muntaha"
author: "Sidratul Muntaha"
info: "Frontend Developer | Branding Designer | CSE Undergrad at CUET"
transition: slide-left
class: text-center
---

# 👋 Hi, I’m Sidratul  

CSE Undergraduate @ **CUET**  
Frontend Developer | Branding Designer  

💡 Passionate about blending **creativity + technology** to build solutions that are functional, aesthetic, and impactful.  

---

# 💻 Frontend Projects

## Zero Waste Challenge App ♻️
- React + Django, gamified dashboard with tasks, points, badges, leaderboard  
- Eco-friendly theme, authentication & profile system  

## Mentor-Mentee Scheduling System 👥
- React + Spring Boot + MySQL  
- Session scheduling, feedback collection, expertise visibility  

## Libra Jewelry Shop 💍
- Django (templates only)  
- Cart, SSLCommerz checkout, reviews, profile management  

🔗 [GitHub Projects](https://github.com/sidratulm)  

---

# 🎨 Branding & Design

🏆 Champion — Cyber Awareness Poster Presentation  
🎭 CUET Events & Competitions — posters, banners, visual assets  
✨ Creative branding concepts for university clubs  

> My design philosophy: **Consistency, Clarity, and Storytelling**  

---

# 🚀 Skills

**Frontend Development**  
- React, Django, Python, SQL  
- Responsive UI, API integration  

**Design & Branding**  
- Figma, Canva, Illustrator  
- Posters, logos, UI mockups  

**Core Strengths**  
- Teamwork 🤝 Leadership 🎤 Problem-Solving 🧩  

---

# 🌱 Values

🌍 Sustainability & impact-driven design  
💡 Curiosity & innovation in tech  
💖 Compassion & collaboration in every project  

---

# 🌐 Let’s Connect

📧 **Email:** yourmail@example.com  
🔗 **GitHub:** github.com/sidratulm  
🔗 **LinkedIn:** linkedin.com/in/sidratulm  

Thanks for viewing my portfolio ✨  
